const clockEl = document.getElementById('clock');
const ampmEl = document.getElementById('ampm');

function updateClock() {
  const now = new Date();

  let hours = now.getHours();
  const minutes = now.getMinutes();
  const seconds = now.getSeconds();

  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours === 0 ? 12 : hours;

  const hh = String(hours).padStart(2, '0');
  const mm = String(minutes).padStart(2, '0');
  const ss = String(seconds).padStart(2, '0');

  clockEl.textContent = `${hh}:${mm}:${ss}`;
  ampmEl.textContent = ampm;
}

updateClock();
setInterval(updateClock, 1000);
