Live Clock UI

How to run:
1. Extract the ZIP file.
2. Open the folder.
3. Double-click index.html
   OR
   Right-click index.html -> Open with browser.

Features:
- Shows current time in HH:MM:SS format
- Displays AM/PM
- Updates automatically every second
- Modern real-time UI
