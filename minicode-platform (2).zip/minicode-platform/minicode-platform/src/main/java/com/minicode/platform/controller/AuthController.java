package com.minicode.platform.controller;

import com.minicode.platform.dto.RegisterRequest;
import com.minicode.platform.service.UserService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/register")
    public String registerPage(Model model) {
        model.addAttribute("registerRequest", new RegisterRequest());
        return "register";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute RegisterRequest request,
                           BindingResult result,
                           Model model) {

        if (result.hasErrors()) {
            return "register";
        }

        String response = userService.register(request);

        if (!response.equals("SUCCESS")) {
            model.addAttribute("error", response);
            return "register";
        }

        return "redirect:/login";
    }
}