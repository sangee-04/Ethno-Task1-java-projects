package com.minicode.platform.dto;

import jakarta.validation.constraints.NotBlank;

public class RunCodeForm {

    @NotBlank
    private String code;

    @NotBlank
    private String input;

    public RunCodeForm() {
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getInput() {
        return input;
    }

    public void setInput(String input) {
        this.input = input;
    }
}