package com.minicode.platform.service;

import com.minicode.platform.dto.RunResult;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.TimeUnit;

@Service
public class CodeExecutionService {

    public RunResult runJavaCode(String code, String input) {
        Path tempDir = null;
        try {
            if (code == null || code.isBlank()) {
                return new RunResult(false, "", "Code cannot be empty");
            }

            if (!code.contains("class Solution")) {
                return new RunResult(false, "", "Code must contain class Solution");
            }

            tempDir = Files.createTempDirectory("minicode-run");
            Path javaFile = tempDir.resolve("Solution.java");
            Files.writeString(javaFile, code, StandardCharsets.UTF_8);

            ProcessBuilder compileBuilder = new ProcessBuilder("javac", "Solution.java");
            compileBuilder.directory(tempDir.toFile());
            Process compileProcess = compileBuilder.start();

            boolean compileFinished = compileProcess.waitFor(10, TimeUnit.SECONDS);
            if (!compileFinished) {
                compileProcess.destroyForcibly();
                return new RunResult(false, "", "Compilation timed out");
            }

            String compileError = readStream(compileProcess.getErrorStream());
            if (compileProcess.exitValue() != 0) {
                return new RunResult(false, "", compileError);
            }

            ProcessBuilder runBuilder = new ProcessBuilder("java", "Solution");
            runBuilder.directory(tempDir.toFile());
            Process runProcess = runBuilder.start();

            try (BufferedWriter writer = new BufferedWriter(
                    new OutputStreamWriter(runProcess.getOutputStream(), StandardCharsets.UTF_8))) {
                writer.write(input == null ? "" : input);
                writer.flush();
            }

            boolean runFinished = runProcess.waitFor(10, TimeUnit.SECONDS);
            if (!runFinished) {
                runProcess.destroyForcibly();
                return new RunResult(false, "", "Execution timed out");
            }

            String output = readStream(runProcess.getInputStream());
            String error = readStream(runProcess.getErrorStream());

            if (runProcess.exitValue() != 0) {
                return new RunResult(false, "", error);
            }

            return new RunResult(true, output.trim(), error);

        } catch (Exception e) {
            return new RunResult(false, "", e.getMessage());
        } finally {
            if (tempDir != null) {
                deleteDirectory(tempDir.toFile());
            }
        }
    }

    private String readStream(InputStream inputStream) throws IOException {
        return new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
    }

    private void deleteDirectory(File file) {
        if (file == null || !file.exists()) return;
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            if (files != null) {
                for (File child : files) {
                    deleteDirectory(child);
                }
            }
        }
        file.delete();
    }
}