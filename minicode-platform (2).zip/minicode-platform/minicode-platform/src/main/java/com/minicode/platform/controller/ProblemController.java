package com.minicode.platform.controller;

import com.minicode.platform.dto.RunCodeForm;
import com.minicode.platform.dto.RunResult;
import com.minicode.platform.dto.SubmissionForm;
import com.minicode.platform.entity.Problem;
import com.minicode.platform.entity.Submission;
import com.minicode.platform.service.CodeExecutionService;
import com.minicode.platform.service.ProblemService;
import com.minicode.platform.service.SubmissionService;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/problems")
public class ProblemController {

    private final ProblemService problemService;
    private final SubmissionService submissionService;
    private final CodeExecutionService codeExecutionService;

    public ProblemController(ProblemService problemService,
                             SubmissionService submissionService,
                             CodeExecutionService codeExecutionService) {
        this.problemService = problemService;
        this.submissionService = submissionService;
        this.codeExecutionService = codeExecutionService;
    }

    @GetMapping("/{id}")
    public String viewProblem(@PathVariable Long id, Model model) {
        Problem problem = problemService.getByIdWithTestCases(id);

        SubmissionForm submissionForm = new SubmissionForm();
        submissionForm.setCode(problem.getStarterCode() != null ? problem.getStarterCode() : "");

        RunCodeForm runCodeForm = new RunCodeForm();
        runCodeForm.setCode(problem.getStarterCode() != null ? problem.getStarterCode() : "");
        runCodeForm.setInput(problem.getSampleInput() != null ? problem.getSampleInput() : "");

        model.addAttribute("problem", problem);
        model.addAttribute("submissionForm", submissionForm);
        model.addAttribute("runCodeForm", runCodeForm);
        model.addAttribute("runResult", null);
        model.addAttribute("submissionResult", null);

        return "problem-view";
    }

    @PostMapping("/{id}/run")
    public String runCode(@PathVariable Long id,
                          @ModelAttribute("runCodeForm") RunCodeForm runCodeForm,
                          Model model) {
        Problem problem = problemService.getByIdWithTestCases(id);

        SubmissionForm submissionForm = new SubmissionForm();
        submissionForm.setCode(runCodeForm.getCode());

        RunResult runResult = codeExecutionService.runJavaCode(
                runCodeForm.getCode(),
                runCodeForm.getInput()
        );

        model.addAttribute("problem", problem);
        model.addAttribute("submissionForm", submissionForm);
        model.addAttribute("runCodeForm", runCodeForm);
        model.addAttribute("runResult", runResult);
        model.addAttribute("submissionResult", null);

        return "problem-view";
    }

    @PostMapping("/{id}/submit")
    public String submitCode(@PathVariable Long id,
                             @Valid @ModelAttribute("submissionForm") SubmissionForm submissionForm,
                             BindingResult result,
                             Authentication authentication,
                             Model model) {
        Problem problem = problemService.getByIdWithTestCases(id);

        RunCodeForm runCodeForm = new RunCodeForm();
        runCodeForm.setCode(submissionForm.getCode());
        runCodeForm.setInput(problem.getSampleInput() != null ? problem.getSampleInput() : "");

        model.addAttribute("problem", problem);
        model.addAttribute("submissionForm", submissionForm);
        model.addAttribute("runCodeForm", runCodeForm);
        model.addAttribute("runResult", null);

        if (result.hasErrors()) {
            model.addAttribute("submissionResult", null);
            return "problem-view";
        }

        Submission submission = submissionService.submit(
                problem.getId(),
                authentication.getName(),
                submissionForm.getCode()
        );

        model.addAttribute("submissionResult", submission);
        return "problem-view";
    }
}