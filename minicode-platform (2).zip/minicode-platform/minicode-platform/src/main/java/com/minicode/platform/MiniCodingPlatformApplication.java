package com.minicode.platform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiniCodingPlatformApplication {
    public static void main(String[] args) {
        SpringApplication.run(MiniCodingPlatformApplication.class, args);
    }
}
