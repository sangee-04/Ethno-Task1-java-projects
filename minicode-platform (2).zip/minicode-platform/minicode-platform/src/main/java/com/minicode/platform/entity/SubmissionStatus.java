package com.minicode.platform.entity;

public enum SubmissionStatus {
    ACCEPTED,
    WRONG_ANSWER,
    RUNTIME_ERROR
}