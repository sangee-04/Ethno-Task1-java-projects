package com.minicode.platform.service;

import com.minicode.platform.dto.ProblemForm;
import com.minicode.platform.entity.Problem;
import com.minicode.platform.entity.TestCase;
import com.minicode.platform.repo.ProblemRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProblemService {

    private final ProblemRepository problemRepository;
    private final StarterCodeService starterCodeService;

    public ProblemService(ProblemRepository problemRepository,
                          StarterCodeService starterCodeService) {
        this.problemRepository = problemRepository;
        this.starterCodeService = starterCodeService;
    }

    public List<Problem> getAllActive() {
        return problemRepository.findAll();
    }

    public Problem getById(Long id) {
        return problemRepository.findById(id).orElseThrow();
    }

    @Transactional
    public Problem getByIdWithTestCases(Long id) {
        Problem problem = problemRepository.findById(id).orElseThrow();
        if (problem.getTestCases() != null) {
            problem.getTestCases().size();
        }
        return problem;
    }

    public void createProblem(ProblemForm form) {
        Problem problem = new Problem();
        problem.setTitle(form.getTitle());
        problem.setDescription(form.getDescription());
        problem.setSourceUrl(form.getSourceUrl());
        problem.setSampleInput(form.getSampleInput());
        problem.setSampleOutput(form.getSampleOutput());
        problem.setDifficulty(form.getDifficulty());
        problem.setActive(true);

        String starterCode = form.getStarterCode();
        if (starterCode == null || starterCode.isBlank()) {
            starterCode = starterCodeService.generateStarterCode(
                    form.getTitle(),
                    form.getDescription(),
                    form.getSampleInput(),
                    form.getSampleOutput()
            );
        }
        problem.setStarterCode(starterCode);

        TestCase tc1 = new TestCase();
        tc1.setInputData(form.getHiddenInput1());
        tc1.setExpectedOutput(form.getHiddenOutput1());
        tc1.setProblem(problem);

        TestCase tc2 = new TestCase();
        tc2.setInputData(form.getHiddenInput2());
        tc2.setExpectedOutput(form.getHiddenOutput2());
        tc2.setProblem(problem);

        problem.getTestCases().add(tc1);
        problem.getTestCases().add(tc2);

        problemRepository.save(problem);
    }
}