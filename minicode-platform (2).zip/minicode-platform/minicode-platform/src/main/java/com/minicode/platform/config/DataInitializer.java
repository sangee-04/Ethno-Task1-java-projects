package com.minicode.platform.config;

import com.minicode.platform.entity.*;
import com.minicode.platform.repo.ProblemRepository;
import com.minicode.platform.repo.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initData(UserRepository userRepository,
                               ProblemRepository problemRepository,
                               PasswordEncoder passwordEncoder) {
        return args -> {

            if (userRepository.findByUsername("admin").isEmpty()) {
                User admin = new User();
                admin.setUsername("admin");
                admin.setEmail("admin@minicode.com");
                admin.setPassword(passwordEncoder.encode("admin123"));
                admin.setRole(Role.ROLE_ADMIN);
                userRepository.save(admin);
            }

            if (problemRepository.count() == 0) {
                saveProblem(problemRepository,
                        "Sum of Two Numbers",
                        """
                        Read two integers from input and print their sum.

                        Hint:
                        Use Scanner to read two numbers.
                        Store them in variables a and b.
                        Print a + b.
                        """,
                        "10 20",
                        "30",
                        "Easy",
                        starterAddCode(),
                        "10 20",
                        "30",
                        "7 8",
                        "15");

                saveProblem(problemRepository,
                        "Reverse a String",
                        """
                        Read one string and print it in reverse order.

                        Hint:
                        Use StringBuilder.
                        Reverse the input string and print it.
                        """,
                        "hello",
                        "olleh",
                        "Medium",
                        starterReverseStringCode(),
                        "hello",
                        "olleh",
                        "arena",
                        "anera");

                saveProblem(problemRepository,
                        "Maximum of Three Numbers",
                        """
                        Read three integers and print the maximum value.

                        Hint:
                        Compare using Math.max or if-else.
                        """,
                        "5 9 2",
                        "9",
                        "Easy",
                        starterMaxOfThreeCode(),
                        "5 9 2",
                        "9",
                        "12 3 10",
                        "12");

                saveProblem(problemRepository,
                        "Count Vowels",
                        """
                        Read a string and count how many vowels are present.

                        Hint:
                        Convert string to lowercase.
                        Check each character against a, e, i, o, u.
                        """,
                        "education",
                        "5",
                        "Medium",
                        starterCountVowelsCode(),
                        "education",
                        "5",
                        "programming",
                        "3");

                saveProblem(problemRepository,
                        "Palindrome Number",
                        """
                        Read an integer and check whether it is a palindrome.

                        Hint:
                        Reverse the number mathematically and compare with original.
                        Print YES if palindrome, otherwise NO.
                        """,
                        "121",
                        "YES",
                        "Medium",
                        starterPalindromeNumberCode(),
                        "121",
                        "YES",
                        "123",
                        "NO");

                saveProblem(problemRepository,
                        "Factorial of a Number",
                        """
                        Read an integer n and print n factorial.

                        Hint:
                        Use loop multiplication from 1 to n.
                        """,
                        "5",
                        "120",
                        "Easy",
                        starterFactorialCode(),
                        "5",
                        "120",
                        "6",
                        "720");

                saveProblem(problemRepository,
                        "Prime Number Check",
                        """
                        Read an integer and print PRIME if it is prime, otherwise NOT PRIME.

                        Hint:
                        Check divisibility from 2 to sqrt(n).
                        """,
                        "7",
                        "PRIME",
                        "Medium",
                        starterPrimeCheckCode(),
                        "7",
                        "PRIME",
                        "8",
                        "NOT PRIME");

                saveProblem(problemRepository,
                        "Fibonacci Nth Term",
                        """
                        Read an integer n and print the nth Fibonacci number.

                        Hint:
                        Use iteration.
                        F(0)=0, F(1)=1.
                        """,
                        "7",
                        "13",
                        "Medium",
                        starterFibonacciCode(),
                        "7",
                        "13",
                        "10",
                        "55");

                saveProblem(problemRepository,
                        "Array Sum",
                        """
                        Read n followed by n integers and print the sum of all elements.

                        Hint:
                        Use a loop to add all numbers.
                        """,
                        "5 1 2 3 4 5",
                        "15",
                        "Easy",
                        starterArraySumCode(),
                        "5 1 2 3 4 5",
                        "15",
                        "4 10 20 30 40",
                        "100");

                saveProblem(problemRepository,
                        "Longest Word in a Sentence",
                        """
                        Read a full line and print the longest word.

                        Hint:
                        Split the sentence by spaces and compare lengths.
                        """,
                        "java makes coding fun",
                        "coding",
                        "Hard",
                        starterLongestWordCode(),
                        "java makes coding fun",
                        "coding",
                        "practice makes progress",
                        "practice");
            }
        };
    }

    private void saveProblem(ProblemRepository repo,
                             String title,
                             String description,
                             String sampleInput,
                             String sampleOutput,
                             String difficulty,
                             String starterCode,
                             String hiddenInput1,
                             String hiddenOutput1,
                             String hiddenInput2,
                             String hiddenOutput2) {

        Problem problem = new Problem();
        problem.setTitle(title);
        problem.setDescription(description);
        problem.setSampleInput(sampleInput);
        problem.setSampleOutput(sampleOutput);
        problem.setDifficulty(difficulty);
        problem.setStarterCode(starterCode);
        problem.setActive(true);

        TestCase tc1 = new TestCase();
        tc1.setInputData(hiddenInput1);
        tc1.setExpectedOutput(hiddenOutput1);
        tc1.setProblem(problem);

        TestCase tc2 = new TestCase();
        tc2.setInputData(hiddenInput2);
        tc2.setExpectedOutput(hiddenOutput2);
        tc2.setProblem(problem);

        problem.getTestCases().add(tc1);
        problem.getTestCases().add(tc2);

        repo.save(problem);
    }

    private String starterAddCode() {
        return """
                import java.util.*;

                public class Solution {
                    public static void main(String[] args) {
                        Scanner sc = new Scanner(System.in);
                        int a = sc.nextInt();
                        int b = sc.nextInt();
                        System.out.println(a + b);
                    }
                }
                """;
    }

    private String starterReverseStringCode() {
        return """
                import java.util.*;

                public class Solution {
                    public static void main(String[] args) {
                        Scanner sc = new Scanner(System.in);
                        String s = sc.nextLine();
                        System.out.println(new StringBuilder(s).reverse());
                    }
                }
                """;
    }

    private String starterMaxOfThreeCode() {
        return """
                import java.util.*;

                public class Solution {
                    public static void main(String[] args) {
                        Scanner sc = new Scanner(System.in);
                        int a = sc.nextInt();
                        int b = sc.nextInt();
                        int c = sc.nextInt();
                        System.out.println(Math.max(a, Math.max(b, c)));
                    }
                }
                """;
    }

    private String starterCountVowelsCode() {
        return """
                import java.util.*;

                public class Solution {
                    public static void main(String[] args) {
                        Scanner sc = new Scanner(System.in);
                        String s = sc.nextLine().toLowerCase();
                        int count = 0;
                        for (char ch : s.toCharArray()) {
                            if ("aeiou".indexOf(ch) != -1) {
                                count++;
                            }
                        }
                        System.out.println(count);
                    }
                }
                """;
    }

    private String starterPalindromeNumberCode() {
        return """
                import java.util.*;

                public class Solution {
                    public static void main(String[] args) {
                        Scanner sc = new Scanner(System.in);
                        int n = sc.nextInt();
                        int original = n;
                        int rev = 0;
                        while (n > 0) {
                            rev = rev * 10 + n % 10;
                            n /= 10;
                        }
                        System.out.println(original == rev ? "YES" : "NO");
                    }
                }
                """;
    }

    private String starterFactorialCode() {
        return """
                import java.util.*;

                public class Solution {
                    public static void main(String[] args) {
                        Scanner sc = new Scanner(System.in);
                        int n = sc.nextInt();
                        long fact = 1;
                        for (int i = 1; i <= n; i++) {
                            fact *= i;
                        }
                        System.out.println(fact);
                    }
                }
                """;
    }

    private String starterPrimeCheckCode() {
        return """
                import java.util.*;

                public class Solution {
                    public static void main(String[] args) {
                        Scanner sc = new Scanner(System.in);
                        int n = sc.nextInt();
                        if (n < 2) {
                            System.out.println("NOT PRIME");
                            return;
                        }
                        for (int i = 2; i * i <= n; i++) {
                            if (n % i == 0) {
                                System.out.println("NOT PRIME");
                                return;
                            }
                        }
                        System.out.println("PRIME");
                    }
                }
                """;
    }

    private String starterFibonacciCode() {
        return """
                import java.util.*;

                public class Solution {
                    public static void main(String[] args) {
                        Scanner sc = new Scanner(System.in);
                        int n = sc.nextInt();
                        if (n == 0) {
                            System.out.println(0);
                            return;
                        }
                        if (n == 1) {
                            System.out.println(1);
                            return;
                        }
                        int a = 0, b = 1, c = 0;
                        for (int i = 2; i <= n; i++) {
                            c = a + b;
                            a = b;
                            b = c;
                        }
                        System.out.println(b);
                    }
                }
                """;
    }

    private String starterArraySumCode() {
        return """
                import java.util.*;

                public class Solution {
                    public static void main(String[] args) {
                        Scanner sc = new Scanner(System.in);
                        int n = sc.nextInt();
                        int sum = 0;
                        for (int i = 0; i < n; i++) {
                            sum += sc.nextInt();
                        }
                        System.out.println(sum);
                    }
                }
                """;
    }

    private String starterLongestWordCode() {
        return """
                import java.util.*;

                public class Solution {
                    public static void main(String[] args) {
                        Scanner sc = new Scanner(System.in);
                        String line = sc.nextLine();
                        String[] words = line.split("\\\\s+");
                        String longest = "";
                        for (String w : words) {
                            if (w.length() > longest.length()) {
                                longest = w;
                            }
                        }
                        System.out.println(longest);
                    }
                }
                """;
    }
}