package com.minicode.platform.service;

import org.springframework.stereotype.Service;

@Service
public class StarterCodeService {

    public String generateStarterCode(String title, String description, String sampleInput, String sampleOutput) {
        return """
                import java.util.*;

                public class Solution {
                    public static void main(String[] args) {
                        Scanner sc = new Scanner(System.in);

                        // Read input here
                        // Write your logic here
                        // Print output here

                    }
                }
                """;
    }
}