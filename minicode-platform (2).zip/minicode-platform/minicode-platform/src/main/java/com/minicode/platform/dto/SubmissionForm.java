package com.minicode.platform.dto;

import jakarta.validation.constraints.NotBlank;

public class SubmissionForm {

    @NotBlank
    private String code;

    public SubmissionForm() {
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}