package com.minicode.platform.dto;

import jakarta.validation.constraints.NotBlank;

public class ProblemForm {

    @NotBlank
    private String title;

    @NotBlank
    private String description;

    private String sourceUrl;

    @NotBlank
    private String sampleInput;

    @NotBlank
    private String sampleOutput;

    @NotBlank
    private String difficulty;

    private String starterCode;

    @NotBlank
    private String hiddenInput1;

    @NotBlank
    private String hiddenOutput1;

    @NotBlank
    private String hiddenInput2;

    @NotBlank
    private String hiddenOutput2;

    public ProblemForm() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSourceUrl() {
        return sourceUrl;
    }

    public void setSourceUrl(String sourceUrl) {
        this.sourceUrl = sourceUrl;
    }

    public String getSampleInput() {
        return sampleInput;
    }

    public void setSampleInput(String sampleInput) {
        this.sampleInput = sampleInput;
    }

    public String getSampleOutput() {
        return sampleOutput;
    }

    public void setSampleOutput(String sampleOutput) {
        this.sampleOutput = sampleOutput;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public String getStarterCode() {
        return starterCode;
    }

    public void setStarterCode(String starterCode) {
        this.starterCode = starterCode;
    }

    public String getHiddenInput1() {
        return hiddenInput1;
    }

    public void setHiddenInput1(String hiddenInput1) {
        this.hiddenInput1 = hiddenInput1;
    }

    public String getHiddenOutput1() {
        return hiddenOutput1;
    }

    public void setHiddenOutput1(String hiddenOutput1) {
        this.hiddenOutput1 = hiddenOutput1;
    }

    public String getHiddenInput2() {
        return hiddenInput2;
    }

    public void setHiddenInput2(String hiddenInput2) {
        this.hiddenInput2 = hiddenInput2;
    }

    public String getHiddenOutput2() {
        return hiddenOutput2;
    }

    public void setHiddenOutput2(String hiddenOutput2) {
        this.hiddenOutput2 = hiddenOutput2;
    }
}