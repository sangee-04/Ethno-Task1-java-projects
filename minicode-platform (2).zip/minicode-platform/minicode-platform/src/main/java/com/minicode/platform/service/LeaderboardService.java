package com.minicode.platform.service;

import com.minicode.platform.dto.LeaderboardEntry;
import com.minicode.platform.entity.Submission;
import com.minicode.platform.entity.SubmissionStatus;
import com.minicode.platform.repo.SubmissionRepository;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class LeaderboardService {

    private final SubmissionRepository submissionRepository;

    public LeaderboardService(SubmissionRepository submissionRepository) {
        this.submissionRepository = submissionRepository;
    }

    public List<LeaderboardEntry> getLeaderboard() {

        List<Submission> submissions = submissionRepository.findAll();

        Map<String, Set<Long>> solvedProblems = new HashMap<>();

        for (Submission s : submissions) {
            if (s.getStatus() == SubmissionStatus.ACCEPTED) {
                String user = s.getUser().getUsername();
                Long problemId = s.getProblem().getId();

                solvedProblems
                        .computeIfAbsent(user, k -> new HashSet<>())
                        .add(problemId);
            }
        }

        List<LeaderboardEntry> leaderboard = new ArrayList<>();

        for (String user : solvedProblems.keySet()) {
            leaderboard.add(
                    new LeaderboardEntry(user, (long) solvedProblems.get(user).size())
            );
        }

        leaderboard.sort((a, b) -> Long.compare(b.getScore(), a.getScore()));

        return leaderboard;
    }
}