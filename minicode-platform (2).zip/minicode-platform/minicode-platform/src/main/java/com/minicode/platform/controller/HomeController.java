package com.minicode.platform.controller;

import com.minicode.platform.entity.Problem;
import com.minicode.platform.service.LeaderboardService;
import com.minicode.platform.service.ProblemService;
import com.minicode.platform.service.SubmissionService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class HomeController {

    private final ProblemService problemService;
    private final SubmissionService submissionService;
    private final LeaderboardService leaderboardService;

    public HomeController(ProblemService problemService,
                          SubmissionService submissionService,
                          LeaderboardService leaderboardService) {
        this.problemService = problemService;
        this.submissionService = submissionService;
        this.leaderboardService = leaderboardService;
    }

    @GetMapping({"/", "/dashboard"})
    public String dashboard(Model model, Authentication authentication) {
        List<Problem> problems = problemService.getAllActive();

        model.addAttribute("problems", problems);
        model.addAttribute("submissions", submissionService.recentSubmissions());
        model.addAttribute("leaderboard", leaderboardService.getLeaderboard());
        model.addAttribute("username", authentication.getName());

        Long firstProblemId = null;
        if (!problems.isEmpty()) {
            firstProblemId = problems.get(0).getId();
        }
        model.addAttribute("firstProblemId", firstProblemId);

        boolean isAdmin = authentication.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
        model.addAttribute("isAdmin", isAdmin);

        return "dashboard";
    }

    @GetMapping("/leaderboard")
    public String leaderboardPage(Model model, Authentication authentication) {
        model.addAttribute("leaderboard", leaderboardService.getLeaderboard());
        model.addAttribute("username", authentication.getName());

        boolean isAdmin = authentication.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
        model.addAttribute("isAdmin", isAdmin);

        return "leaderboard";
    }

    @GetMapping("/access-denied")
    public String accessDenied() {
        return "access-denied";
    }
}