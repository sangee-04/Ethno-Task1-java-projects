package com.minicode.platform.service;

import com.minicode.platform.dto.RunResult;
import com.minicode.platform.entity.*;
import com.minicode.platform.repo.ProblemRepository;
import com.minicode.platform.repo.SubmissionRepository;
import com.minicode.platform.repo.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SubmissionService {

    private final SubmissionRepository submissionRepository;
    private final ProblemRepository problemRepository;
    private final UserRepository userRepository;
    private final CodeExecutionService codeExecutionService;

    public SubmissionService(SubmissionRepository submissionRepository,
                             ProblemRepository problemRepository,
                             UserRepository userRepository,
                             CodeExecutionService codeExecutionService) {
        this.submissionRepository = submissionRepository;
        this.problemRepository = problemRepository;
        this.userRepository = userRepository;
        this.codeExecutionService = codeExecutionService;
    }

    @Transactional
    public Submission submit(Long problemId, String username, String code) {
        Problem problem = problemRepository.findById(problemId).orElseThrow();
        User user = userRepository.findByUsername(username).orElseThrow();

        List<TestCase> testCases = problem.getTestCases();
        int passed = 0;
        String message = "Wrong Answer";

        for (TestCase tc : testCases) {
            RunResult result = codeExecutionService.runJavaCode(code, tc.getInputData());

            if (!result.isSuccess()) {
                message = result.getError();
                Submission submission = buildSubmission(
                        user, problem, code,
                        SubmissionStatus.RUNTIME_ERROR,
                        passed, testCases.size(), message
                );
                return submissionRepository.save(submission);
            }

            String actual = normalize(result.getOutput());
            String expected = normalize(tc.getExpectedOutput());

            if (actual.equals(expected)) {
                passed++;
            } else {
                message = "Expected: " + expected + " but got: " + actual;
                Submission submission = buildSubmission(
                        user, problem, code,
                        SubmissionStatus.WRONG_ANSWER,
                        passed, testCases.size(), message
                );
                return submissionRepository.save(submission);
            }
        }

        Submission submission = buildSubmission(
                user, problem, code,
                SubmissionStatus.ACCEPTED,
                passed, testCases.size(), "Accepted"
        );
        return submissionRepository.save(submission);
    }

    private Submission buildSubmission(User user, Problem problem, String code,
                                       SubmissionStatus status, int passed, int total, String message) {
        Submission submission = new Submission();
        submission.setUser(user);
        submission.setProblem(problem);
        submission.setCode(code);
        submission.setStatus(status);
        submission.setPassedTests(passed);
        submission.setTotalTests(total);
        submission.setMessage(message);
        return submission;
    }

    private String normalize(String s) {
        return s == null ? "" : s.trim().replace("\r\n", "\n").replace("\r", "\n");
    }

    @Transactional
    public List<Submission> recentSubmissions() {
        List<Submission> submissions = submissionRepository.findTop10ByOrderBySubmittedAtDesc();
        for (Submission s : submissions) {
            s.getUser().getUsername();
            s.getProblem().getTitle();
        }
        return submissions;
    }
}