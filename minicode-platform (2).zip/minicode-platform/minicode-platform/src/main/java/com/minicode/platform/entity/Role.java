package com.minicode.platform.entity;

public enum Role {
    ROLE_ADMIN,
    ROLE_USER
}
