package com.minicode.platform.controller;

import com.minicode.platform.dto.ProblemForm;
import com.minicode.platform.service.ProblemService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AdminController {

    private final ProblemService problemService;

    public AdminController(ProblemService problemService) {
        this.problemService = problemService;
    }

    @GetMapping("/admin")
    public String adminPage(Model model) {
        if (!model.containsAttribute("problemForm")) {
            model.addAttribute("problemForm", new ProblemForm());
        }
        return "admin";
    }

    @PostMapping("/admin/problems")
    public String createProblem(@Valid @ModelAttribute("problemForm") ProblemForm form,
                                BindingResult result,
                                Model model) {
        if (result.hasErrors()) {
            return "admin";
        }

        problemService.createProblem(form);
        model.addAttribute("successMessage", "Problem created successfully.");
        model.addAttribute("problemForm", new ProblemForm());
        return "admin";
    }
}