# MiniCode Arena

A mini coding platform built with Spring Boot, Thymeleaf, Spring Security, H2 Database, and Java code evaluation.

## Features
- User registration and login
- Admin adds coding problems with hidden test cases
- Users submit Java solutions
- Automatic judging using hidden test cases
- Leaderboard ranking based on unique accepted problems
- Pleasant responsive UI

## Default Admin Login
- Username: `admin`
- Password: `admin123`

## Important Submission Rule
Users must submit Java code in this format:

```java
import java.util.*;

public class Solution {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // read input and print output
    }
}
```

## Requirements
- Java 17 JDK
- Maven
- Eclipse IDE for Enterprise Java / Spring Tool Suite recommended

## How to Run in Eclipse
1. Extract the zip file.
2. Open Eclipse.
3. Go to **File > Import**.
4. Choose **Maven > Existing Maven Projects**.
5. Click **Next**.
6. Browse and select the extracted `minicode-platform` folder.
7. Click **Finish**.
8. Wait until Maven downloads all dependencies.
9. In the left panel, open:
   - `src/main/java/com/minicode/platform/MiniCodingPlatformApplication.java`
10. Right-click `MiniCodingPlatformApplication.java`.
11. Click **Run As > Java Application** or **Run As > Spring Boot App**.
12. Wait until you see Tomcat started on port `8080`.
13. Open browser and visit:
   - `http://localhost:8080`

## H2 Database Console
- URL: `http://localhost:8080/h2-console`
- JDBC URL: `jdbc:h2:file:./data/minicodearena`
- Username: `sa`
- Password: leave empty

## User Flow
### Normal User
1. Register a new account.
2. Login.
3. Open any problem.
4. Paste Java code.
5. Submit and view result.
6. Check leaderboard on dashboard.

### Admin
1. Login using admin credentials.
2. Open **Admin Panel**.
3. Fill the problem form.
4. Add two hidden test cases.
5. Save.
6. New problem appears on dashboard.

## Run from Command Line
```bash
mvn spring-boot:run
```

## Common Fixes
### If compiler not available
Make sure Eclipse and terminal use **JDK 17**, not JRE.

### If port 8080 is busy
Open `src/main/resources/application.properties` and change:
```properties
server.port=8081
```
Then run again and open `http://localhost:8081`.
