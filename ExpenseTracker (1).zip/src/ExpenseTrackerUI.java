
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class ExpenseTrackerUI {
    private JFrame frame;
    private JTextField amountField, categoryField;
    private DefaultTableModel tableModel;
    private JLabel totalLabel;
    private double total = 0;

    public ExpenseTrackerUI() {
        frame = new JFrame("Expense Tracker");
        frame.setSize(700, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout(10,10));
        panel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        // Top input panel
        JPanel inputPanel = new JPanel(new GridLayout(2,3,10,10));

        inputPanel.add(new JLabel("Amount:"));
        amountField = new JTextField();
        inputPanel.add(amountField);

        JButton addButton = new JButton("Add Expense");
        inputPanel.add(addButton);

        inputPanel.add(new JLabel("Category:"));
        categoryField = new JTextField();
        inputPanel.add(categoryField);

        JButton deleteButton = new JButton("Delete Selected");
        inputPanel.add(deleteButton);

        panel.add(inputPanel, BorderLayout.NORTH);

        // Table
        tableModel = new DefaultTableModel(new String[]{"Amount", "Category"}, 0);
        JTable table = new JTable(tableModel);
        table.setRowHeight(25);
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Bottom panel
        JPanel bottomPanel = new JPanel(new BorderLayout());
        totalLabel = new JLabel("Total: 0");
        totalLabel.setFont(new Font("Arial", Font.BOLD, 16));
        bottomPanel.add(totalLabel, BorderLayout.WEST);

        panel.add(bottomPanel, BorderLayout.SOUTH);

        // Button Actions
        addButton.addActionListener(e -> {
            try {
                double amount = Double.parseDouble(amountField.getText());
                String category = categoryField.getText();

                tableModel.addRow(new Object[]{amount, category});
                total += amount;
                totalLabel.setText("Total: " + total);

                amountField.setText("");
                categoryField.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Enter valid amount!");
            }
        });

        deleteButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                double amount = (double) tableModel.getValueAt(selectedRow, 0);
                total -= amount;
                tableModel.removeRow(selectedRow);
                totalLabel.setText("Total: " + total);
            } else {
                JOptionPane.showMessageDialog(frame, "Select a row to delete!");
            }
        });

        frame.add(panel);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ExpenseTrackerUI());
    }
}
