import java.util.*;

class Person {
    String firstName;
    String lastName;
    int age;
    String gender;
    int index;

    Person(String firstName, String lastName, int age, String gender, int index) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.gender = gender;
        this.index = index;
    }
}

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of people: ");
        int n = sc.nextInt();

        List<Person> people = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for person " + (i + 1));
            System.out.print("First Name: ");
            String firstName = sc.next();

            System.out.print("Last Name: ");
            String lastName = sc.next();

            System.out.print("Age: ");
            int age = sc.nextInt();

            System.out.print("Gender (M/F): ");
            String gender = sc.next();

            people.add(new Person(firstName, lastName, age, gender, i));
        }

        // Sort by age ascending
        Collections.sort(people, (a, b) -> {
            if (a.age == b.age)
                return a.index - b.index;
            return a.age - b.age;
        });

        System.out.println("\n--- Sorted Output ---");
        for (Person p : people) {
            String title = p.gender.equalsIgnoreCase("M") ? "Mr." : "Ms.";
            System.out.println(title + " " + p.firstName + " " + p.lastName);
        }

        sc.close();
    }
}