import java.util.Scanner;

public class LoginValidation {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String correctUsername = "admin";
        String correctPassword = "123";

        int attempts = 0;
        boolean isLoggedIn = false;

        while (attempts < 3 && !isLoggedIn) {

            System.out.print("Enter Username: ");
            String username = sc.nextLine();

            System.out.print("Enter Password: ");
            String password = sc.nextLine();

            // Relational + Logical Operator
            if (username.equals(correctUsername) && password.equals(correctPassword)) {
                System.out.println("✅ Login Successful!");
                isLoggedIn = true;
            } else {
                attempts++;
                System.out.println("❌ Invalid Credentials! Attempts left: " + (3 - attempts));
            }
        }

        if (!isLoggedIn) {
            System.out.println("🚫 Account Blocked! Too many failed attempts.");
        }

        sc.close();
    }
}
