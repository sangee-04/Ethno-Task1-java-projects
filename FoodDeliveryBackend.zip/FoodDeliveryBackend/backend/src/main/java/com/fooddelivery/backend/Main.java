package com.fooddelivery.backend;
import java.sql.*;
import java.util.Scanner;

public class Main {

    // 🔴 CHANGE YOUR PASSWORD HERE
	private static final String URL ="jdbc:mysql://localhost:3306/food_delivery_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "Root@12345";

    public static void main(String[] args) {

        try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {

            System.out.println("✅ Connected to Database Successfully!");

            Scanner sc = new Scanner(System.in);

            while (true) {

                System.out.println("\n===== FOOD DELIVERY MENU =====");
                System.out.println("1. View Restaurants");
                System.out.println("2. View Food Items");
                System.out.println("3. Exit");
                System.out.print("Choose option: ");

                int choice = sc.nextInt();

                switch (choice) {
                    case 1:
                        viewRestaurants(con);
                        break;

                    case 2:
                        System.out.print("Enter Restaurant ID: ");
                        int rid = sc.nextInt();
                        viewFoodItems(con, rid);
                        break;

                    case 3:
                        System.out.println("👋 Exiting...");
                        return;

                    default:
                        System.out.println("Invalid choice!");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void viewRestaurants(Connection con) throws SQLException {

        String sql = "SELECT restaurant_id, name, rating FROM Restaurant";

        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery(sql);

        System.out.println("\n--- Restaurants ---");

        while (rs.next()) {
            System.out.println(
                    rs.getInt("restaurant_id") + " | " +
                            rs.getString("name") + " | Rating: " +
                            rs.getDouble("rating"));
        }
    }

    private static void viewFoodItems(Connection con, int restaurantId)
            throws SQLException {

        String sql = "SELECT food_item_id, item_name, price FROM Food_Item WHERE restaurant_id=?";

        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, restaurantId);

        ResultSet rs = ps.executeQuery();

        System.out.println("\n--- Food Items ---");

        boolean found = false;

        while (rs.next()) {
            found = true;
            System.out.println(
                    rs.getInt("food_item_id") + " | " +
                            rs.getString("item_name") + " | ₹" +
                            rs.getDouble("price"));
        }

        if (!found) {
            System.out.println("No items found for this restaurant.");
        }
    }
}