class Person {
    private int salary = 50000;
    public int getSalary() {
        return salary;
    }
}
class Employee extends Person {
    void showSalary() {
        System.out.println("Salary: " + getSalary());
    }
    public static void main(String[] args) {       
        Employee e = new Employee();
        e.showSalary();
    }
}
