package BP;
class BankAccount {
    private double balance;
    public void deposit(double amount) {
        balance += amount;
    }public void withdraw(double amount) {
        if (amount <= balance)
            balance -= amount;
        else
            System.out.println("Insufficient Balance");
    }public void showBalance() {
        System.out.println("Balance: ₹" + balance);
    }
    public static void main(String[] args) {
        BankAccount user = new BankAccount();
        user.deposit(1000000);
        user.withdraw(30000);
        user.showBalance();
    }
}