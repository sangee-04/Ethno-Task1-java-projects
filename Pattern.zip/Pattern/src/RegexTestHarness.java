import java.io.Console;
import java.util.Scanner;
import java.util.regex.*;

public class RegexTestHarness {
    public static void main(String[] args) {
        Console console = System.console();
        Scanner sc = (console == null) ? new Scanner(System.in) : null;

        while (true) {
            String regex = (console != null)
                    ? console.readLine("%nEnter your regex: ")
                    : readLine(sc, "\nEnter your regex: ");

            Pattern pattern = Pattern.compile(regex);

            String input = (console != null)
                    ? console.readLine("Enter input string to search: ")
                    : readLine(sc, "Enter input string to search: ");

            Matcher matcher = pattern.matcher(input);

            boolean found = false;
            while (matcher.find()) {
                if (console != null) {
                    console.format("I found the text \"%s\" starting at index %d and ending at index %d.%n",
                            matcher.group(), matcher.start(), matcher.end());
                } else {
                    System.out.printf("I found the text \"%s\" starting at index %d and ending at index %d.%n",
                            matcher.group(), matcher.start(), matcher.end());
                }
                found = true;
            }

            if (!found) {
                if (console != null) console.format("No match found.%n");
                else System.out.println("No match found.");
            }
        }
    }

    private static String readLine(Scanner sc, String prompt) {
        System.out.print(prompt);
        return sc.nextLine();
    }
}