package com.example.bmi;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.text.DecimalFormat;

public class BMICalculator extends JFrame {
    private final JTextField weightField;
    private final JTextField heightField;
    private final JLabel bmiValueLabel;
    private final JLabel statusLabel;
    private final JLabel suggestionLabel;
    private final JPanel resultCard;
    private final DecimalFormat decimalFormat = new DecimalFormat("0.00");

    public BMICalculator() {
        setTitle("BMI Calculator - Real Time UI");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 500);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(650, 450));

        JPanel mainPanel = new GradientPanel();
        mainPanel.setLayout(new GridBagLayout());
        mainPanel.setBorder(new EmptyBorder(25, 25, 25, 25));

        JPanel card = new RoundedPanel(30, new Color(255, 255, 255, 240));
        card.setLayout(new BorderLayout(20, 20));
        card.setBorder(new EmptyBorder(25, 25, 25, 25));
        card.setPreferredSize(new Dimension(580, 380));

        JLabel titleLabel = new JLabel("BMI Calculator");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 30));
        titleLabel.setForeground(new Color(24, 42, 73));

        JLabel subtitleLabel = new JLabel("Live BMI updates as you type your details");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        subtitleLabel.setForeground(new Color(90, 96, 110));

        JPanel header = new JPanel();
        header.setOpaque(false);
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.add(titleLabel);
        header.add(Box.createVerticalStrut(6));
        header.add(subtitleLabel);

        JPanel inputPanel = new JPanel(new GridLayout(2, 2, 16, 16));
        inputPanel.setOpaque(false);

        JLabel weightLabel = createFieldLabel("Weight (kg)");
        JLabel heightLabel = createFieldLabel("Height (cm)");

        weightField = createTextField();
        heightField = createTextField();

        inputPanel.add(weightLabel);
        inputPanel.add(heightLabel);
        inputPanel.add(weightField);
        inputPanel.add(heightField);

        resultCard = new RoundedPanel(25, new Color(244, 247, 255));
        resultCard.setLayout(new BoxLayout(resultCard, BoxLayout.Y_AXIS));
        resultCard.setBorder(new EmptyBorder(22, 22, 22, 22));

        JLabel resultTitle = new JLabel("Your Result");
        resultTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        resultTitle.setForeground(new Color(32, 52, 87));
        resultTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        bmiValueLabel = new JLabel("--");
        bmiValueLabel.setFont(new Font("Segoe UI", Font.BOLD, 42));
        bmiValueLabel.setForeground(new Color(44, 114, 255));
        bmiValueLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        statusLabel = new JLabel("Enter values to calculate BMI");
        statusLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        statusLabel.setForeground(new Color(77, 86, 102));
        statusLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        suggestionLabel = new JLabel(" ");
        suggestionLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        suggestionLabel.setForeground(new Color(104, 112, 126));
        suggestionLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton resetButton = new JButton("Reset");
        resetButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        resetButton.setFocusPainted(false);
        resetButton.setFont(new Font("Segoe UI", Font.BOLD, 15));
        resetButton.setForeground(Color.WHITE);
        resetButton.setBackground(new Color(44, 114, 255));
        resetButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        resetButton.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        resetButton.addActionListener(e -> resetFields());

        resultCard.add(resultTitle);
        resultCard.add(Box.createVerticalStrut(10));
        resultCard.add(bmiValueLabel);
        resultCard.add(Box.createVerticalStrut(8));
        resultCard.add(statusLabel);
        resultCard.add(Box.createVerticalStrut(6));
        resultCard.add(suggestionLabel);
        resultCard.add(Box.createVerticalStrut(18));
        resultCard.add(resetButton);

        JPanel center = new JPanel(new BorderLayout(0, 20));
        center.setOpaque(false);
        center.add(inputPanel, BorderLayout.NORTH);
        center.add(resultCard, BorderLayout.CENTER);

        card.add(header, BorderLayout.NORTH);
        card.add(center, BorderLayout.CENTER);

        mainPanel.add(card);
        setContentPane(mainPanel);

        addLiveCalculation(weightField);
        addLiveCalculation(heightField);
    }

    private JLabel createFieldLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 16));
        label.setForeground(new Color(45, 55, 72));
        return label;
    }

    private JTextField createTextField() {
        JTextField field = new JTextField();
        field.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(215, 222, 232), 2),
                BorderFactory.createEmptyBorder(10, 14, 10, 14)
        ));
        return field;
    }

    private void addLiveCalculation(JTextField field) {
        field.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                calculateBMI();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                calculateBMI();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                calculateBMI();
            }
        });
    }

    private void calculateBMI() {
        String weightText = weightField.getText().trim();
        String heightText = heightField.getText().trim();

        if (weightText.isEmpty() || heightText.isEmpty()) {
            showDefaultState();
            return;
        }

        try {
            double weight = Double.parseDouble(weightText);
            double heightCm = Double.parseDouble(heightText);

            if (weight <= 0 || heightCm <= 0) {
                showError("Enter positive values only");
                return;
            }

            double heightM = heightCm / 100.0;
            double bmi = weight / (heightM * heightM);
            bmiValueLabel.setText(decimalFormat.format(bmi));

            if (bmi < 18.5) {
                applyResultStyle(new Color(255, 153, 0), "Underweight", "Try a balanced diet and regular health checkups.");
            } else if (bmi < 25) {
                applyResultStyle(new Color(34, 166, 99), "Normal", "Great job! Maintain your healthy routine.");
            } else if (bmi < 30) {
                applyResultStyle(new Color(255, 99, 71), "Overweight", "Consider exercise and mindful eating habits.");
            } else {
                applyResultStyle(new Color(220, 53, 69), "Obese", "A fitness plan and medical advice may help.");
            }
        } catch (NumberFormatException ex) {
            showError("Please enter valid numbers");
        }
    }

    private void applyResultStyle(Color accent, String status, String suggestion) {
        bmiValueLabel.setForeground(accent);
        statusLabel.setText(status);
        statusLabel.setForeground(accent.darker());
        suggestionLabel.setText(suggestion);
        resultCard.setBackground(new Color(
                Math.min(255, accent.getRed() + 25),
                Math.min(255, accent.getGreen() + 25),
                Math.min(255, accent.getBlue() + 25),
                35
        ));
        resultCard.repaint();
    }

    private void showDefaultState() {
        bmiValueLabel.setText("--");
        bmiValueLabel.setForeground(new Color(44, 114, 255));
        statusLabel.setText("Enter values to calculate BMI");
        statusLabel.setForeground(new Color(77, 86, 102));
        suggestionLabel.setText(" ");
        resultCard.setBackground(new Color(244, 247, 255));
        resultCard.repaint();
    }

    private void showError(String message) {
        bmiValueLabel.setText("--");
        bmiValueLabel.setForeground(new Color(220, 53, 69));
        statusLabel.setText("Invalid Input");
        statusLabel.setForeground(new Color(220, 53, 69));
        suggestionLabel.setText(message);
        resultCard.setBackground(new Color(255, 240, 240));
        resultCard.repaint();
    }

    private void resetFields() {
        weightField.setText("");
        heightField.setText("");
        showDefaultState();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
            }
            new BMICalculator().setVisible(true);
        });
    }

    static class GradientPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            int w = getWidth();
            int h = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, new Color(98, 183, 255), w, h, new Color(123, 104, 238));
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, w, h);
            g2d.dispose();
        }
    }

    static class RoundedPanel extends JPanel {
        private final int radius;

        RoundedPanel(int radius, Color bgColor) {
            this.radius = radius;
            setOpaque(false);
            setBackground(bgColor);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
            g2.dispose();
            super.paintComponent(g);
        }
    }
}
