BMI Calculator - Eclipse Project

Features:
- Java Swing UI
- Real-time BMI updates while typing
- Modern gradient interface
- BMI category with suggestion
- Reset button

How to run in Eclipse:
1. Extract the ZIP file.
2. Open Eclipse.
3. Click File > Import.
4. Choose General > Existing Projects into Workspace.
5. Click Next.
6. Select the extracted bmi_calculator_project folder.
7. Click Finish.
8. In Package Explorer, open:
   src > com.example.bmi > BMICalculator.java
9. Right-click BMICalculator.java
10. Click Run As > Java Application

Requirements:
- JDK 17 or newer recommended

How it works:
- Enter weight in kilograms
- Enter height in centimeters
- BMI updates instantly
