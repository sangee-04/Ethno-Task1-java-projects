const counterElement = document.getElementById('counter');
const statusText = document.getElementById('statusText');
const increaseBtn = document.getElementById('increaseBtn');
const decreaseBtn = document.getElementById('decreaseBtn');
const resetBtn = document.getElementById('resetBtn');

let count = 0;

function updateCounter() {
  counterElement.textContent = count;
  counterElement.classList.remove('positive', 'negative', 'neutral', 'pop');

  if (count > 0) {
    counterElement.classList.add('positive');
    statusText.textContent = 'The counter is positive.';
  } else if (count < 0) {
    counterElement.classList.add('negative');
    statusText.textContent = 'The counter is negative.';
  } else {
    counterElement.classList.add('neutral');
    statusText.textContent = 'The counter is currently neutral.';
  }

  void counterElement.offsetWidth;
  counterElement.classList.add('pop');
}

increaseBtn.addEventListener('click', () => {
  count++;
  updateCounter();
});

decreaseBtn.addEventListener('click', () => {
  count--;
  updateCounter();
});

resetBtn.addEventListener('click', () => {
  count = 0;
  updateCounter();
});

updateCounter();
