import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        while (true) {

            System.out.print("Enter your email: ");
            String email = sc.nextLine();

            User user = new User(email);

            boolean result = Validator.validate(user);

            if (result) {
                break;   // stop when email is valid
            }

        }

        sc.close();
    }
}