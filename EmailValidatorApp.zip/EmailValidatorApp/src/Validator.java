import java.lang.reflect.Field;
import java.util.regex.Pattern;

public class Validator {

    public static boolean validate(Object obj) {

        Class<?> clazz = obj.getClass();

        for (Field field : clazz.getDeclaredFields()) {

            if (field.isAnnotationPresent(EmailValidation.class)) {

                field.setAccessible(true);

                try {

                    String email = (String) field.get(obj);

                    String regex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";

                    boolean isValid = Pattern.matches(regex, email);

                    if (isValid) {
                        System.out.println("Valid email: " + email);
                        return true;
                    } else {
                        System.out.println("Email is not valid -> " + email);
                        return false;
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        return false;
    }
}