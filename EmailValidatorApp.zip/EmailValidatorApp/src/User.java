public class User {

    @EmailValidation(message = "Email is not valid")
    private String email;

    public User(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }
}