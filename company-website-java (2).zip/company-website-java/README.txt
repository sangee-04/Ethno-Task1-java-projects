BRIGHTWAVE - MODERN COMPANY WEBSITE (JAVA + HTML + CSS + JS)
=============================================================

PROJECT TYPE:
Spring Boot Maven project
Java 17
Runs in Eclipse as a normal Java application

WHAT IS FUNCTIONAL:
1. Hero section with CTA buttons
2. Features section with icons
3. Testimonials cards
4. Pricing plans with working Java backend API
5. Contact form with validation and backend submission
6. Success popup modal for pricing and contact form
7. Responsive modern UI
8. Admin endpoint to view submitted messages while app is running

IMPORTANT LINKS AFTER RUNNING:
Home page:
http://localhost:8080/

View submitted contact messages:
http://localhost:8080/admin/messages

HOW TO RUN IN ECLIPSE:
----------------------
OPTION 1 - BEST METHOD
1. Open Eclipse.
2. Go to File -> Import.
3. Choose Maven -> Existing Maven Projects.
4. Click Next.
5. Browse and select the extracted folder: company-website-java
6. Click Finish.
7. Wait for Maven dependencies to download.
8. Make sure JDK 17 is installed and configured in Eclipse.
9. Open file:
   src/main/java/com/example/companywebsite/CompanyWebsiteApplication.java
10. Right click the file.
11. Click Run As -> Java Application.
12. Open browser and go to:
    http://localhost:8080/

OPTION 2 - RUN AS MAVEN
1. Right click project.
2. Run As -> Maven build...
3. In Goals, type:
   spring-boot:run
4. Click Run.
5. Open:
   http://localhost:8080/

IF PORT 8080 IS BUSY:
1. Open file src/main/resources/application.properties
2. Change:
   server.port=8080
   to for example:
   server.port=9090
3. Save and run again.
4. Open:
   http://localhost:9090/

REQUIREMENTS:
- Java 17 or above
- Eclipse IDE for Enterprise Java / Eclipse with Maven support
- Internet connection first time to download Maven dependencies

PROJECT STRUCTURE:
- src/main/java -> Java backend code
- src/main/resources/templates/index.html -> Main HTML page
- src/main/resources/static/css/style.css -> Styling
- src/main/resources/static/js/app.js -> Functional frontend actions

NOTES:
- Contact form submissions are stored in memory only while app is running.
- When you stop the application, stored messages are cleared.
- Pricing buttons call the Java backend and show confirmation popup.

CATCHY BRAND LINES USED:
- Build a brand that people remember, trust, and love.
- Design bold. Build smart. Grow beyond expectations.
- From clicks to customers — let your brand shine brighter.

