package com.example.companywebsite.model;

import jakarta.validation.constraints.NotBlank;

public class PricingRequest {

    @NotBlank(message = "Plan name is required")
    private String planName;

    public String getPlanName() {
        return planName;
    }

    public void setPlanName(String planName) {
        this.planName = planName;
    }
}
