package com.example.companywebsite.service;

import com.example.companywebsite.model.ContactMessage;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

@Service
public class WebsiteService {

    private final List<Map<String, String>> submissions = new CopyOnWriteArrayList<>();

    public Map<String, String> saveMessage(ContactMessage message) {
        Map<String, String> saved = Map.of(
                "name", message.getName(),
                "email", message.getEmail(),
                "subject", message.getSubject(),
                "message", message.getMessage(),
                "time", LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy hh:mm a"))
        );
        submissions.add(saved);
        return saved;
    }

    public List<Map<String, String>> getAllMessages() {
        List<Map<String, String>> copy = new ArrayList<>(submissions);
        Collections.reverse(copy);
        return copy;
    }

    public String getPlanMessage(String planName) {
        return switch (planName.toLowerCase()) {
            case "starter" -> "Great choice! Starter gives you a clean launchpad to build your digital presence.";
            case "growth" -> "Excellent pick! Growth is perfect for scaling faster with smarter tools and premium support.";
            case "visionary" -> "Brilliant move! Visionary unlocks the full power of a premium digital experience.";
            default -> "Thank you for choosing a plan with BrightWave.";
        };
    }
}
