package com.example.companywebsite.controller;

import com.example.companywebsite.model.ContactMessage;
import com.example.companywebsite.model.PricingRequest;
import com.example.companywebsite.service.WebsiteService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.Map;

@Controller
public class WebController {

    private final WebsiteService websiteService;

    public WebController(WebsiteService websiteService) {
        this.websiteService = websiteService;
    }

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("contact", new ContactMessage());
        return "index";
    }

    @PostMapping("/api/contact")
    @ResponseBody
    public ResponseEntity<?> submitContact(@Valid @RequestBody ContactMessage contactMessage,
                                           BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            Map<String, String> errors = new HashMap<>();
            bindingResult.getFieldErrors().forEach(error -> errors.put(error.getField(), error.getDefaultMessage()));
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "errors", errors
            ));
        }

        Map<String, String> saved = websiteService.saveMessage(contactMessage);
        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
                "success", true,
                "title", "Message Sent Successfully",
                "message", "Thanks, " + saved.get("name") + "! Our team will connect with you shortly.",
                "savedAt", saved.get("time")
        ));
    }

    @PostMapping("/api/pricing/select")
    @ResponseBody
    public ResponseEntity<?> selectPlan(@Valid @RequestBody PricingRequest pricingRequest,
                                        BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "Please choose a valid plan."
            ));
        }

        String planName = pricingRequest.getPlanName();
        return ResponseEntity.ok(Map.of(
                "success", true,
                "title", "Subscription Selected",
                "message", websiteService.getPlanMessage(planName),
                "tagline", "From clicks to customers — let your brand shine brighter."
        ));
    }

    @GetMapping("/admin/messages")
    @ResponseBody
    public ResponseEntity<?> allMessages() {
        return ResponseEntity.ok(websiteService.getAllMessages());
    }
}
