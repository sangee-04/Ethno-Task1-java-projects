const modal = document.getElementById('modal');
const modalTitle = document.getElementById('modalTitle');
const modalMessage = document.getElementById('modalMessage');
const modalTagline = document.getElementById('modalTagline');
const closeModalBtn = document.getElementById('closeModal');
const modalActionBtn = document.getElementById('modalAction');
const contactForm = document.getElementById('contactForm');
const planButtons = document.querySelectorAll('.plan-btn');

function showModal(title, message, tagline = '') {
    modalTitle.textContent = title;
    modalMessage.textContent = message;
    modalTagline.textContent = tagline;
    modal.classList.remove('hidden');
}

function closeModal() {
    modal.classList.add('hidden');
}

closeModalBtn.addEventListener('click', closeModal);
modalActionBtn.addEventListener('click', closeModal);
modal.addEventListener('click', (event) => {
    if (event.target === modal) {
        closeModal();
    }
});

function clearErrors() {
    ['name', 'email', 'subject', 'message'].forEach((field) => {
        document.getElementById(`${field}Error`).textContent = '';
    });
}

contactForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    clearErrors();

    const payload = {
        name: document.getElementById('name').value.trim(),
        email: document.getElementById('email').value.trim(),
        subject: document.getElementById('subject').value.trim(),
        message: document.getElementById('message').value.trim()
    };

    try {
        const response = await fetch('/api/contact', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });

        const data = await response.json();

        if (!response.ok) {
            if (data.errors) {
                Object.entries(data.errors).forEach(([field, message]) => {
                    const errorField = document.getElementById(`${field}Error`);
                    if (errorField) {
                        errorField.textContent = message;
                    }
                });
            }
            return;
        }

        contactForm.reset();
        showModal(data.title, `${data.message} Received at: ${data.savedAt}`, 'Your message is in motion — and so is your next big opportunity.');
    } catch (error) {
        showModal('Something went wrong', 'Unable to send your message right now. Please try again.', 'Good websites recover fast — and so do we.');
    }
});

planButtons.forEach((button) => {
    button.addEventListener('click', async () => {
        const planName = button.getAttribute('data-plan');

        try {
            const response = await fetch('/api/pricing/select', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ planName })
            });

            const data = await response.json();

            if (data.success) {
                showModal(data.title, data.message, data.tagline);
            } else {
                showModal('Oops!', 'Please select a valid pricing plan.');
            }
        } catch (error) {
            showModal('Server Error', 'We could not process your plan right now.', 'Big ideas deserve a second click.');
        }
    });
});
