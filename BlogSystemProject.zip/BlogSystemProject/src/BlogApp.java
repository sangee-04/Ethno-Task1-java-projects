import java.util.*;

class Blog {
    private static int counter = 1;
    private int id;
    private String title;
    private String content;
    private String author;
    private Date date;
    private String category;

    public Blog(String title, String content, String author, String category) {
        this.id = counter++;
        this.title = title;
        this.content = content;
        this.author = author;
        this.date = new Date();
        this.category = category;
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getContent() { return content; }
    public String getAuthor() { return author; }
    public Date getDate() { return date; }
    public String getCategory() { return category; }

    public void setTitle(String title) { this.title = title; }
    public void setContent(String content) { this.content = content; }
    public void setCategory(String category) { this.category = category; }

    @Override
    public String toString() {
        return "ID: " + id + "\nTitle: " + title + "\nAuthor: " + author +
               "\nDate: " + date + "\nCategory: " + category + "\nContent: " + content;
    }
}

class BlogSystem {
    private List<Blog> blogs = new ArrayList<>();

    public void addBlog(String title, String content, String author, String category) {
        blogs.add(new Blog(title, content, author, category));
        System.out.println("Blog added successfully!");
    }

    public void editBlog(int id, String newTitle, String newContent, String newCategory) {
        for (Blog blog : blogs) {
            if (blog.getId() == id) {
                blog.setTitle(newTitle);
                blog.setContent(newContent);
                blog.setCategory(newCategory);
                System.out.println("Blog updated successfully!");
                return;
            }
        }
        System.out.println("Blog not found!");
    }

    public void deleteBlog(int id) {
        blogs.removeIf(blog -> blog.getId() == id);
        System.out.println("Blog deleted successfully!");
    }

    public void viewAllBlogs() {
        if (blogs.isEmpty()) {
            System.out.println("No blogs available.");
            return;
        }
        for (Blog blog : blogs) {
            System.out.println(blog);
            System.out.println("----------------------------");
        }
    }

    public void viewBlogById(int id) {
        for (Blog blog : blogs) {
            if (blog.getId() == id) {
                System.out.println(blog);
                return;
            }
        }
        System.out.println("Blog not found!");
    }

    public void searchByTitle(String title) {
        for (Blog blog : blogs) {
            if (blog.getTitle().equalsIgnoreCase(title)) {
                System.out.println(blog);
                return;
            }
        }
        System.out.println("No blog found with that title.");
    }

    public void filterByCategory(String category) {
        boolean found = false;
        for (Blog blog : blogs) {
            if (blog.getCategory().equalsIgnoreCase(category)) {
                System.out.println(blog);
                System.out.println("----------------------------");
                found = true;
            }
        }
        if (!found) {
            System.out.println("No blogs found in this category.");
        }
    }
}

public class BlogApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BlogSystem system = new BlogSystem();

        while (true) {
            System.out.println("\n--- Blog System ---");
            System.out.println("1. Add Blog (Admin)");
            System.out.println("2. Edit Blog (Admin)");
            System.out.println("3. Delete Blog (Admin)");
            System.out.println("4. View All Blogs");
            System.out.println("5. View Blog by ID");
            System.out.println("6. Search Blog by Title");
            System.out.println("7. Filter Blogs by Category");
            System.out.println("8. Exit");
            System.out.print("Choose an option: ");

            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter title: ");
                    String title = sc.nextLine();
                    System.out.print("Enter content: ");
                    String content = sc.nextLine();
                    System.out.print("Enter author: ");
                    String author = sc.nextLine();
                    System.out.print("Enter category: ");
                    String category = sc.nextLine();
                    system.addBlog(title, content, author, category);
                    break;
                case 2:
                    System.out.print("Enter blog ID to edit: ");
                    int editId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter new title: ");
                    String newTitle = sc.nextLine();
                    System.out.print("Enter new content: ");
                    String newContent = sc.nextLine();
                    System.out.print("Enter new category: ");
                    String newCategory = sc.nextLine();
                    system.editBlog(editId, newTitle, newContent, newCategory);
                    break;
                case 3:
                    System.out.print("Enter blog ID to delete: ");
                    int deleteId = sc.nextInt();
                    system.deleteBlog(deleteId);
                    break;
                case 4:
                    system.viewAllBlogs();
                    break;
                case 5:
                    System.out.print("Enter blog ID: ");
                    int viewId = sc.nextInt();
                    system.viewBlogById(viewId);
                    break;
                case 6:
                    System.out.print("Enter blog title: ");
                    String searchTitle = sc.nextLine();
                    system.searchByTitle(searchTitle);
                    break;
                case 7:
                    System.out.print("Enter category: ");
                    String filterCategory = sc.nextLine();
                    system.filterByCategory(filterCategory);
                    break;
                case 8:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
}
