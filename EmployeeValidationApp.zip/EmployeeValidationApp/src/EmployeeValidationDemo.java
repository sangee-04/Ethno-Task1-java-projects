import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface NotBlank {
    String message() default "must not be blank";
}

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface Regex {
    String value();
    String message() default "has invalid format";
}

class Employee {
    @NotBlank(message = "Employee ID is required")
    @Regex(value = "^EMP\\d{4}$", message = "Employee ID must look like EMP1234")
    private final String employeeId;

    @NotBlank(message = "Name is required")
    @Regex(value = "^[A-Za-z ]{2,50}$", message = "Name must be 2-50 letters/spaces")
    private final String name;

    @NotBlank(message = "Email is required")
    @Regex(value = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$", message = "Email is invalid")
    private final String email;

    @NotBlank(message = "Phone is required")
    @Regex(value = "^[6-9]\\d{9}$", message = "Phone must be 10 digits and start with 6-9")
    private final String phone;

    @NotBlank(message = "Department is required")
    @Regex(value = "^(HR|ENG|FIN|OPS)$", message = "Department must be one of HR, ENG, FIN, OPS")
    private final String department;

    public Employee(String employeeId, String name, String email, String phone, String department) {
        this.employeeId = employeeId;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.department = department;
    }
}

class EmployeeValidator {
    public static List<String> validate(Object target) {
        List<String> errors = new ArrayList<>();
        Class<?> clazz = target.getClass();

        for (Field field : clazz.getDeclaredFields()) {
            field.setAccessible(true);
            Object value;
            try {
                value = field.get(target);
            } catch (IllegalAccessException e) {
                errors.add(field.getName() + ": cannot access value");
                continue;
            }

            NotBlank notBlank = field.getAnnotation(NotBlank.class);
            if (notBlank != null && (value == null || String.valueOf(value).trim().isEmpty())) {
                errors.add(field.getName() + ": " + notBlank.message());
                continue;
            }

            Regex regex = field.getAnnotation(Regex.class);
            if (regex != null && value != null && !String.valueOf(value).trim().isEmpty()) {
                if (!Pattern.matches(regex.value(), String.valueOf(value).trim())) {
                    errors.add(field.getName() + ": " + regex.message());
                }
            }
        }
        return errors;
    }
}

public class EmployeeValidationDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            Employee employee = readEmployeeFromConsole(scanner);

            System.out.println("\n--- Validation Result ---");
            List<String> errors = EmployeeValidator.validate(employee);

            if (errors.isEmpty()) {
                System.out.println("Validation passed ✅");
            } else {
                System.out.println("Validation failed ❌");
                for (String error : errors) {
                    System.out.println("- " + error);
                }
            }

            if (!wantsAnotherEntry(scanner)) {
                break;
            }

            System.out.println();
        }

        scanner.close();
    }

    private static Employee readEmployeeFromConsole(Scanner scanner) {
        System.out.println("Enter employee details for validation:");
        System.out.print("Employee ID (example EMP1234): ");
        String employeeId = scanner.nextLine();

        System.out.print("Name: ");
        String name = scanner.nextLine();

        System.out.print("Email: ");
        String email = scanner.nextLine();

        System.out.print("Phone (10 digits, starts with 6-9): ");
        String phone = scanner.nextLine();

        System.out.print("Department (HR/ENG/FIN/OPS): ");
        String department = scanner.nextLine().toUpperCase();

        return new Employee(employeeId, name, email, phone, department);
    }

    private static boolean wantsAnotherEntry(Scanner scanner) {
        System.out.print("\nPress Enter to add another employee or type 'exit' to quit: ");
        String nextAction = scanner.nextLine().trim();
        return !nextAction.equalsIgnoreCase("exit");
    }
}