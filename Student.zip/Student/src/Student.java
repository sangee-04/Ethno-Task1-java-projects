
class Student {

    // variables (data)
    int id = 101;
    String name = "Sangeetha";

    // method (behavior)
    void show() {
        System.out.println("Student ID: " + id);
        System.out.println("Student Name: " + name);
    }

    // main method
    public static void main(String[] args) {

        // object creation
        Student s = new Student();

        // method call using object
        s.show();
    }
}
