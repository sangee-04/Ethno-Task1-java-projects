const imageThemes = [
  {
    name: 'Nature',
    colors: ['#7c3aed', '#22d3ee'],
    cards: [
      { title: 'Aurora Heights', tag: 'Landscape', category: 'Nature', location: 'Dolomites, Italy', photographer: 'Federico Respini', description: 'A dreamy mountain scene with layered fog, warm sunset light, and cinematic depth.', image: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Coastal Escape', tag: 'Ocean View', category: 'Nature', location: 'Goa, India', photographer: 'Jeremy Bishop', description: 'Soft waves, horizon glow, and a calming seascape that feels immersive in the fullscreen preview.', image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Forest Drift', tag: 'Woodland', category: 'Nature', location: 'Black Forest, Germany', photographer: 'Casey Horner', description: 'A peaceful woodland composition with layered greens and a fresh natural feel.', image: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Desert Bloom', tag: 'Adventure', category: 'Nature', location: 'Arizona, USA', photographer: 'Jake Melara', description: 'Golden tones and textured ridges create beautiful contrast against the glowing interface.', image: 'https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=1400&q=80' },
      { title: 'River Silence', tag: 'Calm Water', category: 'Nature', location: 'Banff, Canada', photographer: 'John Lee', description: 'A quiet river scene with crisp blue water and dramatic alpine depth.', image: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1400&q=80' }
    ]
  },
  {
    name: 'Cats',
    colors: ['#ec4899', '#8b5cf6'],
    cards: [
      { title: 'Velvet Gaze', tag: 'Portrait', category: 'Cats', location: 'Home Studio', photographer: 'Tran Mau Tri Tam', description: 'A regal close-up with expressive eyes and smooth background blur.', image: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Sunny Whiskers', tag: 'Warm Light', category: 'Cats', location: 'Window Corner', photographer: 'The Lucky Neko', description: 'A relaxed cat enjoying soft sunlight and cozy indoor warmth.', image: 'https://images.unsplash.com/photo-1495360010541-f48722b34f7d?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Playful Paws', tag: 'Action', category: 'Cats', location: 'Living Room', photographer: 'Mikhail Vasilyev', description: 'A lively frame full of motion, personality, and curiosity.', image: 'https://images.unsplash.com/photo-1574158622682-e40e69881006?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Royal Rest', tag: 'Calm Mood', category: 'Cats', location: 'Cozy Sofa', photographer: 'Paul Hanaoka', description: 'Soft fur texture and gentle tones make this card feel elegant and comforting.', image: 'https://images.unsplash.com/photo-1533743983669-94fa5c4338ec?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Curious Ears', tag: 'Focus', category: 'Cats', location: 'Minimal Set', photographer: 'Eric Han', description: 'A sharp portrait that highlights alert posture and fine detail.', image: 'https://images.unsplash.com/photo-1511044568932-338cba0ad803?auto=format&fit=crop&w=1400&q=80' }
    ]
  },
  {
    name: 'Dogs',
    colors: ['#f97316', '#06b6d4'],
    cards: [
      { title: 'Golden Run', tag: 'Outdoor', category: 'Dogs', location: 'Open Field', photographer: 'Jamie Street', description: 'A joyful running dog captured with bright energy and movement.', image: 'https://images.unsplash.com/photo-1517849845537-4d257902454a?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Best Friend', tag: 'Portrait', category: 'Dogs', location: 'Park Trail', photographer: 'Charles Deluvio', description: 'A heartwarming portrait with friendly expression and rich detail.', image: 'https://images.unsplash.com/photo-1518717758536-85ae29035b6d?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Forest Walk', tag: 'Adventure', category: 'Dogs', location: 'Pine Woods', photographer: 'Alvan Nee', description: 'A dog surrounded by natural greens and soft cinematic light.', image: 'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Snow Patrol', tag: 'Winter', category: 'Dogs', location: 'Mountain Pass', photographer: 'Ryan Stone', description: 'A crisp winter frame with texture, focus, and a bold cool palette.', image: 'https://images.unsplash.com/photo-1450778869180-41d0601e046e?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Puppy Smile', tag: 'Cute Mood', category: 'Dogs', location: 'Backyard', photographer: 'Mia Anderson', description: 'Playful expression and soft contrast make this card instantly inviting.', image: 'https://images.unsplash.com/photo-1587300003388-59208cc962cb?auto=format&fit=crop&w=1400&q=80' }
    ]
  },
  {
    name: 'Flowers',
    colors: ['#db2777', '#f59e0b'],
    cards: [
      { title: 'Blush Petals', tag: 'Macro', category: 'Flowers', location: 'Garden Conservatory', photographer: 'Annie Spratt', description: 'A delicate floral close-up with layered texture and elegant softness.', image: 'https://images.unsplash.com/photo-1490750967868-88aa4486c946?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Spring Burst', tag: 'Fresh Bloom', category: 'Flowers', location: 'Tulip Field', photographer: 'Roman Kraft', description: 'Colorful petals and bright natural light create a vivid cheerful frame.', image: 'https://images.unsplash.com/photo-1468327768560-75b778cbb551?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Lavender Dream', tag: 'Soft Tones', category: 'Flowers', location: 'Provence, France', photographer: 'Heather Ford', description: 'Long rows of lavender stretch into a dreamy pastel horizon.', image: 'https://images.unsplash.com/photo-1462275646964-a0e3386b89fa?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Wild Meadow', tag: 'Natural Bloom', category: 'Flowers', location: 'Country Meadow', photographer: 'Aaron Burden', description: 'A relaxed botanical scene with organic colors and gentle movement.', image: 'https://images.unsplash.com/photo-1470509037663-253afd7f0f51?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Rose Light', tag: 'Classic', category: 'Flowers', location: 'Rose House', photographer: 'Caroline Hernandez', description: 'A timeless floral portrait with dramatic highlights and refined depth.', image: 'https://images.unsplash.com/photo-1518709268805-4e9042af2176?auto=format&fit=crop&w=1400&q=80' }
    ]
  },
  {
    name: 'City',
    colors: ['#3b82f6', '#8b5cf6'],
    cards: [
      { title: 'Neon Streets', tag: 'Nightlife', category: 'City', location: 'Tokyo, Japan', photographer: 'Jazmin Quaynor', description: 'A moody city view filled with reflections, color, and electric nighttime energy.', image: 'https://images.unsplash.com/photo-1493246507139-91e8fad9978e?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Skyline Glass', tag: 'Modern', category: 'City', location: 'Dubai, UAE', photographer: 'Denys Nevozhai', description: 'A polished skyline scene with layered architecture and clean symmetry.', image: 'https://images.unsplash.com/photo-1514565131-fce0801e5785?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Urban Rush', tag: 'Street Life', category: 'City', location: 'New York, USA', photographer: 'Luca Bravo', description: 'Fast-paced movement and glowing tones give this card dynamic momentum.', image: 'https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Rain Reflections', tag: 'Moody', category: 'City', location: 'Seoul, South Korea', photographer: 'Alex Knight', description: 'Reflective pavement, neon highlights, and strong atmosphere in one frame.', image: 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Bridge Lines', tag: 'Architecture', category: 'City', location: 'San Francisco, USA', photographer: 'Timon Studler', description: 'Geometric forms and soft haze produce a cinematic city composition.', image: 'https://images.unsplash.com/photo-1494526585095-c41746248156?auto=format&fit=crop&w=1400&q=80' }
    ]
  },
  {
    name: 'Beach',
    colors: ['#06b6d4', '#f59e0b'],
    cards: [
      { title: 'Blue Horizon', tag: 'Tropical', category: 'Beach', location: 'Maldives', photographer: 'Asad Photo', description: 'Crystal water, bright sky, and clean composition make this theme feel instantly fresh.', image: 'https://images.unsplash.com/photo-1500375592092-40eb2168fd21?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Sunset Shore', tag: 'Golden Hour', category: 'Beach', location: 'Bali, Indonesia', photographer: 'Sebastian Pena Lambarri', description: 'Warm sunset light reflects beautifully across sand and sea.', image: 'https://images.unsplash.com/photo-1505118380757-91f5f5632de0?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Palm Escape', tag: 'Relax', category: 'Beach', location: 'Phuket, Thailand', photographer: 'Raimond Klavins', description: 'A vacation-style scene with palms, blue water, and airy tropical mood.', image: 'https://images.unsplash.com/photo-1519046904884-53103b34b206?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Sea Breeze', tag: 'Minimal', category: 'Beach', location: 'Kerala, India', photographer: 'Aron Visuals', description: 'A minimalist coastline with soothing color balance and calm motion.', image: 'https://images.unsplash.com/photo-1501959915551-4e8b96f9f1de?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Waves & Light', tag: 'Motion', category: 'Beach', location: 'Bondi, Australia', photographer: 'Jeremy Bishop', description: 'Rolling water and bright highlights bring movement to the expanding layout.', image: 'https://images.unsplash.com/photo-1500375592092-40eb2168fd21?auto=format&fit=crop&w=1400&q=80' }
    ]
  },
  {
    name: 'Mountains',
    colors: ['#10b981', '#3b82f6'],
    cards: [
      { title: 'Alpine Mirror', tag: 'Lake View', category: 'Mountains', location: 'Swiss Alps', photographer: 'Eberhard Grossgasteiger', description: 'A mirror-like lake reflecting dramatic peaks and clear blue sky.', image: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Summit Trail', tag: 'Adventure', category: 'Mountains', location: 'Himachal Pradesh, India', photographer: 'Kalen Emsley', description: 'A scenic route winding through high-altitude terrain and fresh open space.', image: 'https://images.unsplash.com/photo-1464823063530-08f10ed1a2dd?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Cloud Peaks', tag: 'Atmospheric', category: 'Mountains', location: 'Nepal', photographer: 'Tobias Reich', description: 'Layered clouds and sharp ridge lines create cinematic scale.', image: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Snow Line', tag: 'Cold Tone', category: 'Mountains', location: 'Iceland', photographer: 'Zhenyu Luo', description: 'A crisp, cold mountain frame with strong contrast and clean light.', image: 'https://images.unsplash.com/photo-1486870591958-9b9d0d1dda99?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Morning Ridge', tag: 'Sunrise', category: 'Mountains', location: 'Ladakh, India', photographer: 'Simon Berger', description: 'First light across the ridges adds depth and a peaceful visual rhythm.', image: 'https://images.unsplash.com/photo-1508261303786-6d3f5f111f85?auto=format&fit=crop&w=1400&q=80' }
    ]
  },
  {
    name: 'Birds',
    colors: ['#0ea5e9', '#84cc16'],
    cards: [
      { title: 'Sky Glide', tag: 'Flight', category: 'Birds', location: 'Coastal Sky', photographer: 'Ray Hennessy', description: 'A bird in elegant flight with beautiful wing detail and open sky.', image: 'https://images.unsplash.com/photo-1444464666168-49d633b86797?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Feather Focus', tag: 'Portrait', category: 'Birds', location: 'Wetland Reserve', photographer: 'David Clode', description: 'Rich feather texture and strong eye contact make this preview especially striking.', image: 'https://images.unsplash.com/photo-1444464666168-49d633b86797?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Forest Wings', tag: 'Wildlife', category: 'Birds', location: 'Rainforest Edge', photographer: 'Joshua J. Cotten', description: 'Natural greens and balanced framing create a vivid wildlife moment.', image: 'https://images.unsplash.com/photo-1452570053594-1b985d6ea890?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Lake Watch', tag: 'Stillness', category: 'Birds', location: 'Mirror Lake', photographer: 'Gary Bendig', description: 'A quiet bird scene with reflective water and calm composition.', image: 'https://images.unsplash.com/photo-1501706362039-c6e80948a1a2?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Golden Perch', tag: 'Warm Tone', category: 'Birds', location: 'Sunlit Meadow', photographer: 'Boris Smokrovic', description: 'Warm colors and delicate balance give this card a graceful look.', image: 'https://images.unsplash.com/photo-1425082661705-1834bfd09dca?auto=format&fit=crop&w=1400&q=80' }
    ]
  },
  {
    name: 'Food',
    colors: ['#ef4444', '#f59e0b'],
    cards: [
      { title: 'Chef Table', tag: 'Fine Dining', category: 'Food', location: 'Studio Kitchen', photographer: 'Jay Wennington', description: 'Clean plating, rich tones, and sharp detail create a premium visual feel.', image: 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Berry Delight', tag: 'Dessert', category: 'Food', location: 'Pastry Set', photographer: 'Brooke Lark', description: 'A colorful dessert layout with depth, texture, and a soft luxury look.', image: 'https://images.unsplash.com/photo-1482049016688-2d3e1b311543?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Fresh Harvest', tag: 'Healthy', category: 'Food', location: 'Morning Table', photographer: 'Ella Olsson', description: 'Bright ingredients and fresh styling make this theme lively and clean.', image: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Coffee Mood', tag: 'Cafe', category: 'Food', location: 'Urban Cafe', photographer: 'Nathan Dumlao', description: 'A cozy coffee composition with rich shadows and inviting warmth.', image: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Pasta Night', tag: 'Comfort', category: 'Food', location: 'Dinner Scene', photographer: 'Joseph Gonzalez', description: 'Bold color and texture bring a satisfying, handcrafted look to the card.', image: 'https://images.unsplash.com/photo-1473093295043-cdd812d0e601?auto=format&fit=crop&w=1400&q=80' }
    ]
  },
  {
    name: 'Cars',
    colors: ['#64748b', '#38bdf8'],
    cards: [
      { title: 'Midnight Drive', tag: 'Luxury', category: 'Cars', location: 'City Street', photographer: 'Adrian Dascal', description: 'A polished sports car scene with dramatic reflections and premium finish.', image: 'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Track Vision', tag: 'Performance', category: 'Cars', location: 'Race Circuit', photographer: 'Tim Meyer', description: 'Strong lines, speed-focused composition, and crisp detail throughout.', image: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Chrome Edge', tag: 'Design', category: 'Cars', location: 'Showroom', photographer: 'Erik Mclean', description: 'A sleek close-up highlighting form, polish, and modern automotive styling.', image: 'https://images.unsplash.com/photo-1502877338535-766e1452684a?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Road Story', tag: 'Travel', category: 'Cars', location: 'Highway Route', photographer: 'Obi Onyeador', description: 'A long road composition that feels cinematic and open-ended.', image: 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?auto=format&fit=crop&w=1400&q=80' },
      { title: 'Sunset Machine', tag: 'Golden Hour', category: 'Cars', location: 'Desert Road', photographer: 'Max Andrey', description: 'Warm sunset color and bold body lines create a striking final card.', image: 'https://images.unsplash.com/photo-1489824904134-891ab64532f1?auto=format&fit=crop&w=1400&q=80' }
    ]
  }
];

const gallery = document.getElementById('gallery');
const playBtn = document.getElementById('playBtn');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');
const shuffleBtn = document.getElementById('shuffleBtn');
const themeBtn = document.getElementById('themeBtn');
const cardCount = document.getElementById('cardCount');
const activeIndexLabel = document.getElementById('activeIndex');
const themeNameLabel = document.getElementById('themeName');
const themePills = document.getElementById('themePills');

const modal = document.getElementById('modal');
const modalImage = document.getElementById('modalImage');
const modalTitle = document.getElementById('modalTitle');
const modalDescription = document.getElementById('modalDescription');
const modalBadge = document.getElementById('modalBadge');
const modalCategory = document.getElementById('modalCategory');
const modalLocation = document.getElementById('modalLocation');
const modalPhotographer = document.getElementById('modalPhotographer');
const closeModal = document.getElementById('closeModal');

let activeIndex = 0;
let autoPlay = true;
let autoTimer = null;
let themeIndex = 0;
let galleryData = structuredClone(imageThemes[themeIndex].cards);

function applyThemeColors() {
  const [primary, secondary] = imageThemes[themeIndex].colors;
  document.documentElement.style.setProperty('--primary', primary);
  document.documentElement.style.setProperty('--primary-2', secondary);
}

function renderThemePills() {
  themePills.innerHTML = '';
  imageThemes.forEach((theme, index) => {
    const button = document.createElement('button');
    button.className = `theme-pill ${index === themeIndex ? 'active' : ''}`;
    button.textContent = theme.name;
    button.addEventListener('click', () => setTheme(index));
    themePills.appendChild(button);
  });
}

function renderGallery() {
  gallery.innerHTML = '';
  galleryData.forEach((item, index) => {
    const card = document.createElement('article');
    card.className = `card ${index === activeIndex ? 'active' : ''}`;
    card.setAttribute('tabindex', '0');
    card.setAttribute('aria-label', `${item.title} card`);

    card.innerHTML = `
      <img src="${item.image}" alt="${item.title}" />
      <div class="card-content">
        <span class="card-tag">${item.tag}</span>
        <h2 class="card-title">${item.title}</h2>
        <p class="card-desc">${item.description}</p>
        <span class="card-action">Open Preview ↗</span>
      </div>
    `;

    card.addEventListener('click', (e) => {
      const clickedAction = e.target.closest('.card-action');
      if (clickedAction && index === activeIndex) {
        openModal(item);
        return;
      }
      setActive(index);
    });

    card.addEventListener('dblclick', () => openModal(item));
    card.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        if (index === activeIndex) openModal(item);
        else setActive(index);
      }
    });

    gallery.appendChild(card);
  });

  cardCount.textContent = String(galleryData.length).padStart(2, '0');
  themeNameLabel.textContent = imageThemes[themeIndex].name;
  updateActiveLabel();
  renderThemePills();
}

function setActive(index) {
  activeIndex = (index + galleryData.length) % galleryData.length;
  document.querySelectorAll('.card').forEach((card, i) => {
    card.classList.toggle('active', i === activeIndex);
  });
  updateActiveLabel();
}

function updateActiveLabel() {
  activeIndexLabel.textContent = String(activeIndex + 1).padStart(2, '0');
}

function nextCard() {
  setActive(activeIndex + 1);
}

function prevCard() {
  setActive(activeIndex - 1);
}

function toggleAutoplay() {
  autoPlay = !autoPlay;
  playBtn.textContent = autoPlay ? 'Pause Auto' : 'Resume Auto';
  startAutoplay();
}

function startAutoplay() {
  if (autoTimer) clearInterval(autoTimer);
  if (!autoPlay) return;
  autoTimer = setInterval(nextCard, 3200);
}

function shuffleCards() {
  for (let i = galleryData.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [galleryData[i], galleryData[j]] = [galleryData[j], galleryData[i]];
  }
  activeIndex = 0;
  renderGallery();
}

function setTheme(index) {
  themeIndex = index;
  galleryData = structuredClone(imageThemes[themeIndex].cards);
  activeIndex = 0;
  applyThemeColors();
  renderGallery();
}

function cycleTheme() {
  setTheme((themeIndex + 1) % imageThemes.length);
}

function openModal(item) {
  modalImage.src = item.image;
  modalTitle.textContent = item.title;
  modalDescription.textContent = item.description;
  modalBadge.textContent = item.tag;
  modalCategory.textContent = item.category;
  modalLocation.textContent = item.location;
  modalPhotographer.textContent = item.photographer;
  modal.classList.add('open');
  modal.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
}

function hideModal() {
  modal.classList.remove('open');
  modal.setAttribute('aria-hidden', 'true');
  document.body.style.overflow = '';
}

prevBtn.addEventListener('click', prevCard);
nextBtn.addEventListener('click', nextCard);
playBtn.addEventListener('click', toggleAutoplay);
shuffleBtn.addEventListener('click', shuffleCards);
themeBtn.addEventListener('click', cycleTheme);
closeModal.addEventListener('click', hideModal);
modal.querySelector('.modal-backdrop').addEventListener('click', hideModal);

document.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowRight') nextCard();
  if (e.key === 'ArrowLeft') prevCard();
  if (e.key === 'Escape') hideModal();
});

let touchStartX = 0;
let touchEndX = 0;

gallery.addEventListener('touchstart', (e) => {
  touchStartX = e.changedTouches[0].screenX;
}, { passive: true });

gallery.addEventListener('touchend', (e) => {
  touchEndX = e.changedTouches[0].screenX;
  const distance = touchStartX - touchEndX;
  if (Math.abs(distance) > 40) {
    distance > 0 ? nextCard() : prevCard();
  }
}, { passive: true });

applyThemeColors();
renderGallery();
startAutoplay();
