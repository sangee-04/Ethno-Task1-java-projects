Updated version:
- 10 different themes
- functional shuffle button
- detailed preview modal
- autoplay, swipe, keyboard support

Paste/replace these files in your project folder:
1. index.html
2. styles.css
3. script.js

Then open index.html in the browser.
