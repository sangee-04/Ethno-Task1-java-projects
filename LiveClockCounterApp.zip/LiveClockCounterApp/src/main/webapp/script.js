const clockElement = document.getElementById('clock');
const counterValueElement = document.getElementById('counterValue');
const statusText = document.getElementById('statusText');
const increaseBtn = document.getElementById('increaseBtn');
const decreaseBtn = document.getElementById('decreaseBtn');
const resetBtn = document.getElementById('resetBtn');

let count = 0;

function formatNumber(value) {
  return value.toString().padStart(2, '0');
}

function updateClock() {
  const now = new Date();
  let hours = now.getHours();
  const minutes = now.getMinutes();
  const seconds = now.getSeconds();

  const meridiem = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours === 0 ? 12 : hours;

  const formattedTime = `${formatNumber(hours)}:${formatNumber(minutes)}:${formatNumber(seconds)} ${meridiem}`;
  clockElement.textContent = formattedTime;
}

function updateCounterUI() {
  counterValueElement.textContent = count;
  counterValueElement.classList.remove('positive', 'negative', 'neutral');

  if (count > 0) {
    counterValueElement.classList.add('positive');
    statusText.textContent = 'Counter is positive.';
  } else if (count < 0) {
    counterValueElement.classList.add('negative');
    statusText.textContent = 'Counter is negative.';
  } else {
    counterValueElement.classList.add('neutral');
    statusText.textContent = 'Counter is neutral.';
  }
}

increaseBtn.addEventListener('click', () => {
  count += 1;
  updateCounterUI();
});

decreaseBtn.addEventListener('click', () => {
  count -= 1;
  updateCounterUI();
});

resetBtn.addEventListener('click', () => {
  count = 0;
  updateCounterUI();
});

updateClock();
setInterval(updateClock, 1000);
updateCounterUI();